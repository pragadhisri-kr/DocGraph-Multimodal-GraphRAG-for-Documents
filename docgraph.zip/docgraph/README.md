# DocGraph

Upload PDFs, turn them into a **knowledge graph** in Neo4j, then chat with them using
**GraphRAG**: answers are grounded in retrieved passages *and* graph relationships, with citations.

```
PDF → parse (pypdf / Docling OCR) → chunk → LLM entity+relation extraction → Neo4j
Question → full-text search (chunks + entities) → expand through the graph → LLM answer with [S#] citations
```

## Quick start

### Option A: Docker (everything in one command)
```bash
cp .env.example .env            # set GEMINI_API_KEY (or LLM_PROVIDER=ollama)
docker compose up --build       # UI: http://localhost:3000   Neo4j browser: http://localhost:7474
```
Scanned PDFs need OCR: `INSTALL_DOCLING=true docker compose up --build` (large image).

### Option B: local development
```bash
docker compose up -d neo4j

cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt            # + requirements-docling.txt for OCR
cp ../.env.example ../.env                 # set GEMINI_API_KEY
uvicorn app.main:app --reload --port 8000

cd ../frontend && npm install && npm run dev   # http://localhost:5173
```

### Tests
```bash
cd backend && python3 -m unittest discover -s tests -v
```
They need no Neo4j, network or API key (fake LLM and in-memory store).

## Configuration (`.env`)
| Variable | Default | Notes |
|---|---|---|
| `LLM_PROVIDER` | `gemini` | `gemini` or `ollama` (fully local) |
| `GEMINI_API_KEY` / `GEMINI_MODEL` | – / `gemini-2.5-flash` | |
| `OLLAMA_URL` / `OLLAMA_MODEL` | `http://localhost:11434` / `gemma3:4b` | |
| `NEO4J_URI` / `NEO4J_USER` / `NEO4J_PASSWORD` | `bolt://localhost:7687` / `neo4j` / `password123` | |
| `PARSER` | `auto` | `auto` = pypdf, falling back to Docling OCR for scans |
| `CHUNK_CHARS` / `CHUNK_OVERLAP` | `1800` / `200` | |
| `EXTRACT_WORKERS` | `4` | parallel LLM extraction calls |
| `MAX_UPLOAD_MB` | `50` | |

## API
| Method | Path | Purpose |
|---|---|---|
| `POST` | `/api/documents` | Upload a PDF → `{doc_id, job_id}` (processing runs in background) |
| `GET` | `/api/jobs/{id}` | Progress: `status`, `message`, `progress` (0–1), `error` |
| `GET` | `/api/documents` | List documents with page/entity counts |
| `DELETE` | `/api/documents/{id}` | Remove a document and its graph |
| `GET` | `/api/graph?doc_id=&limit=` | Nodes + edges for visualisation |
| `POST` | `/api/chat` | `{question, doc_id?}` → `{answer, sources, facts, entities}` |
| `GET` | `/api/health` | Neo4j / LLM status |

## Design
- **Multiple documents.** Each upload is its own `Document`; delete or scope chat/graph per document
  (the reference version wiped the database on every upload).
- **Graph model:** `(Document)-[:HAS_CHUNK]->(Chunk)-[:MENTIONS]->(Entity)-[:RELATES {type}]->(Entity)`.
- **Entity resolution:** the LLM refers to entities by name, and names are normalised per document, so
  "ACME", "Acme" and "the Acme" become one node instead of one copy per chunk. Relations can't dangle.
- **Safe Cypher:** relationship kinds and entity types are stored as properties, never interpolated
  into queries; Lucene query characters are escaped.
- **Retrieval:** Neo4j full-text indexes on chunks and entities, then graph expansion from matched
  entities (their chunks and relationship facts). No embedding model required.
- **Resilient ingestion:** chunk text is stored first (chat works immediately), extraction is parallel
  with retry/backoff, failed chunks are skipped and reported, and a fully failed ingest is rolled back.
- **Pluggable LLM:** Gemini or Ollama behind a 1-method interface.

## Project layout
```
backend/app/
  core/       text.py (chunking, query building)  extraction.py (prompt, parsing, graph merge)   ← pure, unit-tested
  services/   parsing · llm · store (all Cypher) · ingest · rag · jobs
  api/routes.py   main.py   config.py   schemas.py
backend/tests/   frontend/ (React + Vite + vis-network)   docker-compose.yml
```

## Limitations
- Job status is held in memory, so it is lost on backend restart (documents already in Neo4j are kept).
- Entities are not merged across documents.
- Retrieval is lexical (full-text). Adding vector search would improve paraphrased questions.
- No authentication: run it locally or behind your own auth.
