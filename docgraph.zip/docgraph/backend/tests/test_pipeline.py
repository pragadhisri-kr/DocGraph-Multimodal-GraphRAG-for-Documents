"""End-to-end ingestion + RAG with a fake LLM and an in-memory store (no Neo4j/network needed)."""
import json
import os
import sys
import tempfile
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.modules.setdefault("neo4j", types.SimpleNamespace(GraphDatabase=None))  # store.py imports it

from app.config import Settings
from app.services import ingest as ingest_mod
from app.services.jobs import jobs
from app.services.parsing import ParseError, parse_pdf
from app.services.rag import answer_question


def make_pdf(path, lines):
    """Write a tiny valid single-page text PDF."""
    stream = "BT /F1 12 Tf 50 750 Td 14 TL " + " ".join(f"({l}) Tj T*" for l in lines) + " ET"
    objs = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
        "/Resources << /Font << /F1 5 0 R >> >> >>",
        f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream",
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out, offsets = b"%PDF-1.4\n", []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode()
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    out += "".join(f"{o:010d} 00000 n \n" for o in offsets).encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode()
    open(path, "wb").write(out)


class FakeStore:
    def __init__(self):
        self.doc = self.chunks = self.graph = None
        self.deleted = []

    def ensure_schema(self): pass
    def create_document(self, doc_id, title, pages, chunks): self.doc, self.chunks = (doc_id, title, pages), chunks
    def write_graph(self, doc_id, ents, ments, rels): self.graph = (ents, ments, rels)
    def delete_document(self, doc_id): self.deleted.append(doc_id)

    # retrieval side
    def search_chunks(self, q, doc_id, limit):
        return [{"id": "d:0", "text": "The dental plan covers cleanings.", "page": 1, "doc": "Policy"}] if q else []
    def search_entities(self, q, doc_id, limit):
        return [{"key": "d::dental plan", "name": "Dental Plan", "type": "Coverage", "description": ""}] if q else []
    def chunks_for_entities(self, keys, limit): return []
    def facts_for_entities(self, keys, limit):
        return [] if not keys else [{"source": "Dental Plan", "type": "COVERS", "target": "Cleanings", "description": "twice a year"}]


class FakeLLM:
    def __init__(self, reply=None, fail=False):
        self.reply, self.fail, self.prompts = reply, fail, []

    def generate(self, prompt, json_mode=False):
        self.prompts.append(prompt)
        if self.fail:
            raise RuntimeError("400 bad key")
        return self.reply


EXTRACTION = json.dumps({
    "entities": [{"name": "Dental Plan", "type": "Coverage"}, {"name": "Cleanings", "type": "Benefit"}],
    "relations": [{"source": "Dental Plan", "target": "Cleanings", "type": "covers"}],
})
SETTINGS = Settings(extract_workers=2, chunk_chars=500, chunk_overlap=50)


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.pdf = os.path.join(self.dir, "a.pdf")

    def test_parse_real_pdf(self):
        make_pdf(self.pdf, ["The dental plan covers cleanings.", "Deductible is 50 dollars."])
        pages = parse_pdf(self.pdf, "pypdf")
        self.assertEqual(pages[0].number, 1)
        self.assertIn("dental plan covers cleanings", pages[0].text)

    def test_parse_empty_pdf_raises(self):
        make_pdf(self.pdf, [])
        with self.assertRaises(ParseError):
            parse_pdf(self.pdf, "pypdf")

    def test_ingest_success(self):
        make_pdf(self.pdf, ["The dental plan covers cleanings twice a year."])
        store, job = FakeStore(), jobs.create("doc1")
        ingest_mod.ingest_document(job.id, "doc1", self.pdf, "Policy", SETTINGS, store, FakeLLM(EXTRACTION))
        state = jobs.get(job.id)
        self.assertEqual(state["status"], "done", state)
        self.assertEqual(store.doc, ("doc1", "Policy", 1))
        ents, ments, rels = store.graph
        self.assertEqual({e["key"] for e in ents}, {"doc1::dental plan", "doc1::cleanings"})
        self.assertEqual(rels[0]["type"], "COVERS")
        self.assertFalse(os.path.exists(self.pdf), "upload should be cleaned up")

    def test_ingest_failure_rolls_back(self):
        make_pdf(self.pdf, ["Some text that is long enough to extract from."])
        store, job = FakeStore(), jobs.create("doc2")
        ingest_mod.ingest_document(job.id, "doc2", self.pdf, "P", SETTINGS, store, FakeLLM(fail=True))
        state = jobs.get(job.id)
        self.assertEqual(state["status"], "error")
        self.assertIn("every chunk", state["error"])
        self.assertEqual(store.deleted, ["doc2"])

    def test_rag_answer_includes_sources_and_facts(self):
        llm = FakeLLM("Yes, cleanings are covered [S1].")
        res = answer_question(FakeStore(), llm, "Does the dental plan cover cleanings?")
        self.assertEqual(res["sources"][0]["ref"], "S1")
        self.assertIn("Dental Plan -[COVERS]-> Cleanings", res["facts"])
        self.assertIn("[S1] (Policy, p.1)", llm.prompts[0])

    def test_rag_no_context_skips_llm(self):
        llm = FakeLLM("should not be called")
        res = answer_question(FakeStore(), llm, "?!")   # no usable tokens -> empty query
        self.assertEqual(res["sources"], [])
        self.assertEqual(llm.prompts, [])

    def test_short_text_pdf_not_rejected_without_docling(self):
        make_pdf(self.pdf, ["Tiny but real."])
        self.assertEqual(parse_pdf(self.pdf, "auto")[0].text, "Tiny but real.")


if __name__ == "__main__":
    unittest.main()
