import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.core.extraction import GraphAccumulator, parse_extraction
from app.core.text import chunk_text, lucene_query, normalize_name, normalize_rel_type, query_tokens
from app.services.jobs import JobRegistry
from app.services.llm import is_retryable, with_retries


class TextTests(unittest.TestCase):
    def test_normalize_name(self):
        self.assertEqual(normalize_name("  The  Acme Corp. "), "acme corp")
        self.assertEqual(normalize_name("ACME Corp"), normalize_name("acme   corp"))
        self.assertEqual(normalize_name(""), "")

    def test_normalize_rel_type(self):
        self.assertEqual(normalize_rel_type("is covered by"), "IS_COVERED_BY")
        self.assertEqual(normalize_rel_type("!!!"), "RELATED_TO")

    def test_chunks_respect_limit_and_keep_content(self):
        text = "\n\n".join(f"Paragraph {i}. " + "word " * 60 for i in range(20))
        chunks = chunk_text(text, max_chars=500, overlap=80)
        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(len(c) <= 500 for c in chunks))
        joined = "\n".join(chunks)
        for i in range(20):
            self.assertIn(f"Paragraph {i}.", joined)

    def test_chunk_overlap_repeats_text(self):
        text = "\n\n".join("alpha beta gamma delta " * 10 + str(i) for i in range(6))
        chunks = chunk_text(text, max_chars=300, overlap=60)
        self.assertTrue(any(chunks[i][:30].split()[0] in chunks[i - 1] for i in range(1, len(chunks))))

    def test_oversized_paragraph_and_sentence_are_split(self):
        self.assertTrue(all(len(c) <= 100 for c in chunk_text("x" * 1000, 100, 0)))
        sentences = " ".join(f"Sentence number {i} is here." for i in range(50))
        self.assertTrue(all(len(c) <= 200 for c in chunk_text(sentences, 200, 0)))

    def test_empty_and_invalid(self):
        self.assertEqual(chunk_text("", 100, 10), [])
        with self.assertRaises(ValueError):
            chunk_text("abc", 0)

    def test_query_building(self):
        self.assertEqual(query_tokens("What is the deductible for dental?"), ["deductible", "dental"])
        self.assertEqual(lucene_query(["a+b", "c:d"]), r"a\+b OR c\:d")
        self.assertEqual(lucene_query([]), "")


class ExtractionTests(unittest.TestCase):
    RAW = """```json
    {"entities":[{"name":"Acme Insurance","type":"Organization","description":"Insurer"},
                 {"name":"Dental Plan","type":"Coverage"}],
     "relations":[{"source":"Acme Insurance","target":"Dental Plan","type":"offers"},
                  {"source":"Dental Plan","target":"Orthodontics","type":"excludes"},
                  {"source":"Dental Plan","target":"dental plan","type":"self"}]}
    ```"""

    def test_parse_fenced_json_adds_missing_endpoints_and_skips_self_loops(self):
        ex = parse_extraction(self.RAW)
        names = {e.name for e in ex.entities}
        self.assertEqual(names, {"Acme Insurance", "Dental Plan", "Orthodontics"})
        self.assertEqual([r.type for r in ex.relations], ["OFFERS", "EXCLUDES"])

    def test_garbage_never_raises(self):
        for raw in ["", "not json", "{broken", "[]", '{"entities": "x", "relations": 5}', None]:
            ex = parse_extraction(raw)
            self.assertEqual((ex.entities, ex.relations), ([], []))

    def test_accumulator_merges_across_chunks(self):
        acc = GraphAccumulator("d1")
        acc.add("d1:0", parse_extraction('{"entities":[{"name":"Acme","type":"Concept"}],"relations":[]}'))
        acc.add("d1:1", parse_extraction(
            '{"entities":[{"name":"ACME","type":"Organization","description":"An insurer"},{"name":"Plan"}],'
            '"relations":[{"source":"Acme","target":"Plan","type":"OFFERS"}]}'))
        ents = {e["key"]: e for e in acc.entity_rows()}
        self.assertEqual(len(ents), 2)
        acme = ents["d1::acme"]
        self.assertEqual((acme["type"], acme["description"]), ("Organization", "An insurer"))
        mentions = {(m["chunk_id"], m["key"]) for m in acc.mention_rows()}
        self.assertIn(("d1:0", "d1::acme"), mentions)
        self.assertIn(("d1:1", "d1::acme"), mentions)
        self.assertEqual(len(acc.relation_rows()), 1)


class InfraTests(unittest.TestCase):
    def test_retry_classification(self):
        self.assertTrue(is_retryable(Exception("429 RESOURCE_EXHAUSTED")))
        self.assertFalse(is_retryable(Exception("400 invalid argument")))

    def test_with_retries_recovers_then_gives_up(self):
        calls = {"n": 0}

        def flaky():
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("503 unavailable")
            return "ok"

        self.assertEqual(with_retries(flaky, sleep=lambda _: None), "ok")

        def always_bad():
            raise RuntimeError("400 bad request")

        with self.assertRaises(RuntimeError):
            with_retries(always_bad, sleep=lambda _: None)

    def test_job_registry(self):
        reg = JobRegistry()
        job = reg.create("doc1")
        reg.update(job.id, status="parsing", progress=0.5)
        got = reg.get(job.id)
        self.assertEqual((got["status"], got["progress"], got["doc_id"]), ("parsing", 0.5, "doc1"))
        self.assertIsNone(reg.get("nope"))


if __name__ == "__main__":
    unittest.main()
