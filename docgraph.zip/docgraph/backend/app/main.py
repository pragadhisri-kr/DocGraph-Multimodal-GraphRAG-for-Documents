import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.routes import router
from .config import get_settings
from .services.store import Neo4jStore

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("docgraph")


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    store = Neo4jStore(s.neo4j_uri, s.neo4j_user, s.neo4j_password)
    try:
        store.ensure_schema()
    except Exception as exc:  # noqa: BLE001 - retried at first upload
        log.warning("Neo4j schema setup deferred: %s", exc)
    app.state.store = store
    yield
    store.close()


app = FastAPI(title="DocGraph API", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in get_settings().cors_origins.split(",") if o.strip()],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)
