"""LLM providers behind one tiny interface: generate(prompt, json_mode) -> str."""
import json
import logging
import random
import time
import urllib.request
from functools import lru_cache
from typing import Callable, TypeVar

from ..config import Settings, get_settings

log = logging.getLogger(__name__)
T = TypeVar("T")


class LLMConfigError(RuntimeError):
    """Raised when the selected provider is not configured."""


def is_retryable(exc: Exception) -> bool:
    msg = str(exc).lower()
    return any(t in msg for t in ("429", "500", "502", "503", "504", "resource_exhausted",
                                  "rate limit", "unavailable", "overloaded", "timed out", "timeout"))


def with_retries(fn: Callable[[], T], attempts: int = 5, base_delay: float = 2.0,
                 sleep: Callable[[float], None] = time.sleep) -> T:
    """Exponential backoff with jitter for transient provider errors."""
    for i in range(attempts):
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            if i == attempts - 1 or not is_retryable(exc):
                raise
            delay = base_delay * (2 ** i) + random.uniform(0, 1)
            log.warning("LLM call failed (%s); retrying in %.1fs", exc, delay)
            sleep(delay)
    raise RuntimeError("unreachable")


class LLM:
    def generate(self, prompt: str, json_mode: bool = False) -> str:  # pragma: no cover
        raise NotImplementedError


class GeminiLLM(LLM):
    def __init__(self, api_key: str, model: str):
        from google import genai  # imported lazily so the app boots without the SDK
        self._client = genai.Client(api_key=api_key)
        self._model = model

    def generate(self, prompt: str, json_mode: bool = False) -> str:
        from google.genai import types
        cfg = types.GenerateContentConfig(response_mime_type="application/json") if json_mode else None

        def call() -> str:
            return self._client.models.generate_content(model=self._model, contents=prompt, config=cfg).text or ""

        return with_retries(call)


class OllamaLLM(LLM):
    def __init__(self, url: str, model: str):
        self._url = url.rstrip("/")
        self._model = model

    def generate(self, prompt: str, json_mode: bool = False) -> str:
        body = {"model": self._model, "prompt": prompt, "stream": False, "options": {"temperature": 0}}
        if json_mode:
            body["format"] = "json"

        def call() -> str:
            req = urllib.request.Request(f"{self._url}/api/generate", json.dumps(body).encode(),
                                         {"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read()).get("response", "")

        return with_retries(call)


def build_llm(s: Settings) -> LLM:
    if s.llm_provider == "ollama":
        return OllamaLLM(s.ollama_url, s.ollama_model)
    if s.llm_provider == "gemini":
        if not s.gemini_api_key:
            raise LLMConfigError("GEMINI_API_KEY is not set. Add it to .env (or set LLM_PROVIDER=ollama).")
        return GeminiLLM(s.gemini_api_key, s.gemini_model)
    raise LLMConfigError(f"Unknown LLM_PROVIDER '{s.llm_provider}' (use 'gemini' or 'ollama').")


@lru_cache
def get_llm() -> LLM:
    return build_llm(get_settings())
