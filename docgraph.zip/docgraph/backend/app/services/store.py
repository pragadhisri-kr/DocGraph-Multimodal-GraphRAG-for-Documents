"""Neo4j access layer. All Cypher lives here.

Graph model:
  (Document)-[:HAS_CHUNK]->(Chunk)-[:MENTIONS]->(Entity)-[:RELATES {type}]->(Entity)
Entities are scoped per document (key = "<doc_id>::<normalised name>"). Relationship kinds are
stored in a property, so no user/LLM text is ever interpolated into Cypher.
"""
import logging
from typing import Dict, List, Optional

from neo4j import GraphDatabase

log = logging.getLogger(__name__)
BATCH = 500

SCHEMA = [
    "CREATE CONSTRAINT doc_id IF NOT EXISTS FOR (d:Document) REQUIRE d.id IS UNIQUE",
    "CREATE CONSTRAINT chunk_id IF NOT EXISTS FOR (c:Chunk) REQUIRE c.id IS UNIQUE",
    "CREATE CONSTRAINT entity_key IF NOT EXISTS FOR (e:Entity) REQUIRE e.key IS UNIQUE",
    "CREATE FULLTEXT INDEX chunk_text IF NOT EXISTS FOR (c:Chunk) ON EACH [c.text]",
    "CREATE FULLTEXT INDEX entity_text IF NOT EXISTS FOR (e:Entity) ON EACH [e.name, e.description]",
]


def _batches(rows: List[dict]):
    for i in range(0, len(rows), BATCH):
        yield rows[i:i + BATCH]


class Neo4jStore:
    def __init__(self, uri: str, user: str, password: str):
        self._driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self) -> None:
        self._driver.close()

    def _run(self, query: str, **params) -> List[dict]:
        records, _, _ = self._driver.execute_query(query, parameters_=params)
        return [r.data() for r in records]

    def healthy(self) -> bool:
        try:
            self._driver.verify_connectivity()
            return True
        except Exception as exc:  # noqa: BLE001
            log.warning("Neo4j unreachable: %s", exc)
            return False

    def ensure_schema(self) -> None:
        for stmt in SCHEMA:
            self._run(stmt)

    # ---- writes -------------------------------------------------------------------------
    def create_document(self, doc_id: str, title: str, pages: int, chunks: List[dict]) -> None:
        self._run(
            "MERGE (d:Document {id: $id}) "
            "SET d.title = $title, d.pages = $pages, d.chunk_count = $n, d.created_at = datetime().epochSeconds",
            id=doc_id, title=title, pages=pages, n=len(chunks),
        )
        for batch in _batches(chunks):
            self._run(
                """
                MATCH (d:Document {id: $doc_id})
                UNWIND $rows AS row
                MERGE (c:Chunk {id: row.id})
                SET c.text = row.text, c.page = row.page, c.index = row.index, c.doc_id = $doc_id
                MERGE (d)-[:HAS_CHUNK]->(c)
                """,
                doc_id=doc_id, rows=batch,
            )

    def write_graph(self, doc_id: str, entities: List[dict], mentions: List[dict], relations: List[dict]) -> None:
        for batch in _batches(entities):
            self._run(
                """
                UNWIND $rows AS row
                MERGE (e:Entity {key: row.key})
                SET e.name = row.name, e.type = row.type, e.description = row.description, e.doc_id = $doc_id
                """,
                doc_id=doc_id, rows=batch,
            )
        for batch in _batches(mentions):
            self._run(
                """
                UNWIND $rows AS row
                MATCH (c:Chunk {id: row.chunk_id})
                MATCH (e:Entity {key: row.key})
                MERGE (c)-[:MENTIONS]->(e)
                """,
                rows=batch,
            )
        for batch in _batches(relations):
            self._run(
                """
                UNWIND $rows AS row
                MATCH (a:Entity {key: row.source})
                MATCH (b:Entity {key: row.target})
                MERGE (a)-[r:RELATES {type: row.type}]->(b)
                SET r.description = row.description, r.doc_id = $doc_id
                """,
                doc_id=doc_id, rows=batch,
            )

    def delete_document(self, doc_id: str) -> None:
        self._run("MATCH (n) WHERE n.doc_id = $id DETACH DELETE n", id=doc_id)
        self._run("MATCH (d:Document {id: $id}) DETACH DELETE d", id=doc_id)

    # ---- reads --------------------------------------------------------------------------
    def list_documents(self) -> List[dict]:
        return self._run(
            """
            MATCH (d:Document)
            OPTIONAL MATCH (e:Entity {doc_id: d.id})
            WITH d, count(e) AS entities
            RETURN d.id AS id, d.title AS title, d.pages AS pages, d.chunk_count AS chunks,
                   entities, d.created_at AS created_at
            ORDER BY d.created_at DESC
            """
        )

    def search_chunks(self, query: str, doc_id: Optional[str], limit: int) -> List[dict]:
        if not query:
            return []
        return self._run(
            """
            CALL db.index.fulltext.queryNodes('chunk_text', $q) YIELD node, score
            WHERE $doc_id IS NULL OR node.doc_id = $doc_id
            MATCH (d:Document {id: node.doc_id})
            RETURN node.id AS id, node.text AS text, node.page AS page, d.title AS doc, score
            ORDER BY score DESC LIMIT $limit
            """,
            q=query, doc_id=doc_id, limit=limit,
        )

    def search_entities(self, query: str, doc_id: Optional[str], limit: int) -> List[dict]:
        if not query:
            return []
        return self._run(
            """
            CALL db.index.fulltext.queryNodes('entity_text', $q) YIELD node, score
            WHERE $doc_id IS NULL OR node.doc_id = $doc_id
            RETURN node.key AS key, node.name AS name, node.type AS type, node.description AS description
            ORDER BY score DESC LIMIT $limit
            """,
            q=query, doc_id=doc_id, limit=limit,
        )

    def chunks_for_entities(self, keys: List[str], limit: int) -> List[dict]:
        if not keys:
            return []
        return self._run(
            """
            MATCH (c:Chunk)-[:MENTIONS]->(e:Entity) WHERE e.key IN $keys
            MATCH (d:Document {id: c.doc_id})
            WITH c, d, count(DISTINCT e) AS hits
            RETURN c.id AS id, c.text AS text, c.page AS page, d.title AS doc
            ORDER BY hits DESC LIMIT $limit
            """,
            keys=keys, limit=limit,
        )

    def facts_for_entities(self, keys: List[str], limit: int) -> List[dict]:
        if not keys:
            return []
        return self._run(
            """
            MATCH (a:Entity)-[r:RELATES]->(b:Entity)
            WHERE a.key IN $keys OR b.key IN $keys
            RETURN a.name AS source, r.type AS type, b.name AS target, r.description AS description
            LIMIT $limit
            """,
            keys=keys, limit=limit,
        )

    def get_graph(self, doc_id: Optional[str], limit: int) -> Dict[str, List[dict]]:
        nodes = self._run(
            """
            MATCH (e:Entity) WHERE $doc_id IS NULL OR e.doc_id = $doc_id
            OPTIONAL MATCH (e)-[r:RELATES]-()
            WITH e, count(r) AS degree
            ORDER BY degree DESC LIMIT $limit
            RETURN e.key AS id, e.name AS name, e.type AS type, e.description AS description, degree
            """,
            doc_id=doc_id, limit=limit,
        )
        keys = [n["id"] for n in nodes]
        edges = self._run(
            """
            MATCH (a:Entity)-[r:RELATES]->(b:Entity)
            WHERE a.key IN $keys AND b.key IN $keys
            RETURN a.key AS source, b.key AS target, r.type AS type, r.description AS description
            """,
            keys=keys,
        ) if keys else []
        return {"nodes": nodes, "edges": edges}
