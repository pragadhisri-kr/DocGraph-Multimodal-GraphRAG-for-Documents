"""Background ingestion: parse -> chunk -> store chunks -> extract graph (parallel) -> store graph."""
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..config import Settings
from ..core.extraction import GraphAccumulator, Extraction, build_prompt, parse_extraction
from ..core.text import chunk_text
from .jobs import jobs
from .llm import LLM
from .parsing import parse_pdf
from .store import Neo4jStore

log = logging.getLogger(__name__)


def _extract(llm: LLM, text: str) -> Extraction:
    return parse_extraction(llm.generate(build_prompt(text), json_mode=True))


def ingest_document(job_id: str, doc_id: str, path: str, title: str,
                    settings: Settings, store: Neo4jStore, llm: LLM) -> None:
    try:
        store.ensure_schema()

        jobs.update(job_id, status="parsing", message="Reading PDF...", progress=0.05)
        pages = parse_pdf(path, settings.parser)

        chunks = []
        for page in pages:
            for piece in chunk_text(page.text, settings.chunk_chars, settings.chunk_overlap):
                idx = len(chunks)
                chunks.append({"id": f"{doc_id}:{idx}", "text": piece, "page": page.number, "index": idx})
        if not chunks:
            raise ValueError("Document produced no text chunks.")

        # Store text first so chat works even if graph extraction is slow or partially fails.
        store.create_document(doc_id, title, len(pages), chunks)
        jobs.update(job_id, status="extracting", message=f"Extracting entities (0/{len(chunks)})...", progress=0.15)

        acc, done, failed = GraphAccumulator(doc_id), 0, 0
        with ThreadPoolExecutor(max_workers=settings.extract_workers) as pool:
            futures = {pool.submit(_extract, llm, c["text"]): c for c in chunks}
            for fut in as_completed(futures):
                chunk = futures[fut]
                try:
                    acc.add(chunk["id"], fut.result())
                except Exception as exc:  # noqa: BLE001
                    failed += 1
                    log.warning("Extraction failed for %s: %s", chunk["id"], exc)
                done += 1
                jobs.update(job_id, message=f"Extracting entities ({done}/{len(chunks)})...",
                            progress=0.15 + 0.75 * done / len(chunks))

        if failed == len(chunks):
            raise RuntimeError("Entity extraction failed for every chunk. Check your LLM settings/quota.")

        jobs.update(job_id, status="writing", message="Writing knowledge graph...", progress=0.92)
        store.write_graph(doc_id, acc.entity_rows(), acc.mention_rows(), acc.relation_rows())

        note = f" ({failed} chunk(s) skipped)" if failed else ""
        jobs.update(job_id, status="done", message=f"Ready{note}", progress=1.0)
    except Exception as exc:  # noqa: BLE001
        log.exception("Ingestion failed for %s", doc_id)
        try:
            store.delete_document(doc_id)
        except Exception:  # noqa: BLE001
            pass
        jobs.update(job_id, status="error", message="Failed", error=str(exc))
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
