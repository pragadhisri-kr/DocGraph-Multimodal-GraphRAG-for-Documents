"""In-memory registry of background ingestion jobs."""
import threading
import uuid
from dataclasses import asdict, dataclass
from typing import Dict, Optional


@dataclass
class Job:
    id: str
    doc_id: str
    status: str = "queued"      # queued | parsing | extracting | writing | done | error
    message: str = "Queued"
    progress: float = 0.0       # 0..1
    error: Optional[str] = None


class JobRegistry:
    def __init__(self) -> None:
        self._jobs: Dict[str, Job] = {}
        self._lock = threading.Lock()

    def create(self, doc_id: str) -> Job:
        job = Job(id=uuid.uuid4().hex[:12], doc_id=doc_id)
        with self._lock:
            self._jobs[job.id] = job
        return job

    def update(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job:
                for k, v in fields.items():
                    setattr(job, k, v)

    def get(self, job_id: str) -> Optional[dict]:
        with self._lock:
            job = self._jobs.get(job_id)
            return asdict(job) if job else None


jobs = JobRegistry()
