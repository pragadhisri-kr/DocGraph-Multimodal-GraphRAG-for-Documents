"""PDF -> per-page text. pypdf for text PDFs; Docling (OCR + tables) for scans or on request."""
import logging
from dataclasses import dataclass
from typing import List, Optional

log = logging.getLogger(__name__)
MIN_TEXT_CHARS = 200   # below this total, a PDF is treated as scanned


class ParseError(RuntimeError):
    pass


@dataclass
class Page:
    number: Optional[int]
    text: str


def _parse_pypdf(path: str) -> List[Page]:
    from pypdf import PdfReader
    reader = PdfReader(path)
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:  # noqa: BLE001
            raise ParseError("PDF is password protected.") from exc
    return [Page(i, (p.extract_text() or "").strip()) for i, p in enumerate(reader.pages, 1)]


def _parse_docling(path: str) -> List[Page]:
    try:
        from docling.document_converter import DocumentConverter
    except ImportError as exc:
        raise ParseError("Docling is not installed (pip install -r requirements-docling.txt).") from exc
    doc = DocumentConverter().convert(path).document
    try:
        return [Page(i, doc.export_to_markdown(page_no=i).strip()) for i in range(1, doc.num_pages() + 1)]
    except TypeError:   # older docling-core without page_no support
        return [Page(None, doc.export_to_markdown().strip())]


def parse_pdf(path: str, parser: str = "auto") -> List[Page]:
    if parser == "docling":
        pages = _parse_docling(path)
    elif parser == "pypdf":
        pages = _parse_pypdf(path)
    else:
        pages = _parse_pypdf(path)
        if sum(len(p.text) for p in pages) < MIN_TEXT_CHARS:
            log.info("Little text layer found; trying Docling OCR")
            try:
                pages = _parse_docling(path)
            except ParseError:
                if not any(p.text for p in pages):
                    raise ParseError("No readable text found. This looks like a scanned PDF; "
                                     "install Docling (requirements-docling.txt) to enable OCR.")
                # short but genuine text PDF: keep what pypdf found
    pages = [p for p in pages if p.text]
    if not pages:
        raise ParseError("No readable text found in this PDF.")
    return pages
