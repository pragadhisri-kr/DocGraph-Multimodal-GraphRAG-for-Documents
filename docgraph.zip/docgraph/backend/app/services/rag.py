"""GraphRAG retrieval + answering.

1. Full-text search over chunks and over entities.
2. Expand from matched entities: chunks that mention them + their relationship facts.
3. Build a numbered context and ask the LLM to answer with [S#] citations.
"""
from typing import Optional

from ..core.text import lucene_query, query_tokens
from .llm import LLM
from .store import Neo4jStore

MAX_SOURCES = 6
MAX_FACTS = 20
SNIPPET = 280

PROMPT = """Answer the question using ONLY the sources and graph facts below.
Be concise and specific. Cite sources inline like [S1], [S2]. If the answer is not supported by
the material, say "I don't have enough information in the uploaded documents."

SOURCES:
{sources}

GRAPH FACTS:
{facts}

QUESTION: {question}

ANSWER:"""


def answer_question(store: Neo4jStore, llm: LLM, question: str, doc_id: Optional[str] = None) -> dict:
    query = lucene_query(query_tokens(question))

    chunk_hits = store.search_chunks(query, doc_id, MAX_SOURCES)
    entities = store.search_entities(query, doc_id, 5)
    keys = [e["key"] for e in entities]

    sources, seen = [], set()
    for c in chunk_hits + store.chunks_for_entities(keys, 3):
        if c["id"] not in seen and len(sources) < MAX_SOURCES:
            seen.add(c["id"])
            sources.append(c)

    facts = store.facts_for_entities(keys, MAX_FACTS)

    if not sources and not facts:
        return {"answer": "I couldn't find anything relevant in the uploaded documents.",
                "sources": [], "facts": [], "entities": []}

    src_block = "\n\n".join(f"[S{i}] ({s['doc']}, p.{s['page'] or '?'})\n{s['text']}" for i, s in enumerate(sources, 1))
    fact_block = "\n".join(
        f"- {f['source']} -[{f['type']}]-> {f['target']}" + (f": {f['description']}" if f.get("description") else "")
        for f in facts) or "(none)"

    answer = llm.generate(PROMPT.format(sources=src_block, facts=fact_block, question=question)).strip()
    return {
        "answer": answer,
        "sources": [{"ref": f"S{i}", "id": s["id"], "doc": s["doc"], "page": s["page"],
                     "snippet": s["text"][:SNIPPET]} for i, s in enumerate(sources, 1)],
        "facts": [f"{f['source']} -[{f['type']}]-> {f['target']}" for f in facts],
        "entities": [e["name"] for e in entities],
    }
