"""Settings, read once from environment variables (.env supported)."""
import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import load_dotenv

_ROOT = Path(__file__).resolve().parents[2]
load_dotenv(_ROOT / ".env")
load_dotenv(_ROOT.parent / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    llm_provider: str = "gemini"          # gemini | ollama
    gemini_api_key: str = ""
    gemini_model: str = "gemini-2.5-flash"
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "gemma3:4b"

    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str = "password123"

    parser: str = "auto"                  # auto | pypdf | docling
    chunk_chars: int = 1800
    chunk_overlap: int = 200
    extract_workers: int = 4
    upload_dir: str = "uploads"
    max_upload_mb: int = 50
    cors_origins: str = "http://localhost:5173"

    @property
    def llm_configured(self) -> bool:
        return self.llm_provider == "ollama" or bool(self.gemini_api_key)


@lru_cache
def get_settings() -> Settings:
    e = os.getenv
    return Settings(
        llm_provider=e("LLM_PROVIDER", "gemini").lower(),
        gemini_api_key=e("GEMINI_API_KEY", ""),
        gemini_model=e("GEMINI_MODEL", "gemini-2.5-flash"),
        ollama_url=e("OLLAMA_URL", "http://localhost:11434"),
        ollama_model=e("OLLAMA_MODEL", "gemma3:4b"),
        neo4j_uri=e("NEO4J_URI", "bolt://localhost:7687"),
        neo4j_user=e("NEO4J_USER", "neo4j"),
        neo4j_password=e("NEO4J_PASSWORD", "password123"),
        parser=e("PARSER", "auto").lower(),
        chunk_chars=_int("CHUNK_CHARS", 1800),
        chunk_overlap=_int("CHUNK_OVERLAP", 200),
        extract_workers=max(1, _int("EXTRACT_WORKERS", 4)),
        upload_dir=e("UPLOAD_DIR", "uploads"),
        max_upload_mb=_int("MAX_UPLOAD_MB", 50),
        cors_origins=e("CORS_ORIGINS", "http://localhost:5173"),
    )
