import { useRef, useState } from 'react'
import { api } from '../api'

export default function Sidebar({ docs, selected, onSelect, onChange }) {
  const input = useRef(null)
  const [job, setJob] = useState(null)
  const [error, setError] = useState(null)
  const busy = job && job.status !== 'done' && job.status !== 'error'

  async function handleFile(file) {
    if (!file) return
    setError(null)
    try {
      const { job_id } = await api.upload(file)
      let current = { status: 'queued', message: 'Uploading...', progress: 0 }
      setJob(current)
      while (current.status !== 'done' && current.status !== 'error') {
        await new Promise((r) => setTimeout(r, 1500))
        current = await api.job(job_id)
        setJob(current)
      }
      if (current.status === 'error') setError(current.error)
      onChange()
    } catch (e) {
      setError(e.message)
      setJob(null)
    }
    if (input.current) input.current.value = ''
  }

  async function remove(e, id) {
    e.stopPropagation()
    if (!window.confirm('Delete this document and its graph?')) return
    await api.remove(id)
    if (selected === id) onSelect(null)
    onChange()
  }

  return (
    <aside>
      <h1>DocGraph</h1>
      <p className="muted">PDF knowledge graph + chat</p>

      <input ref={input} type="file" accept="application/pdf" hidden onChange={(e) => handleFile(e.target.files[0])} />
      <button className="primary" disabled={busy} onClick={() => input.current.click()}>
        {busy ? 'Processing...' : '+ Upload PDF'}
      </button>

      {job && (
        <div className="job">
          <div className="bar"><div style={{ width: `${Math.round(job.progress * 100)}%` }} /></div>
          <small>{job.message}</small>
        </div>
      )}
      {error && <div className="error">{error}</div>}

      <ul>
        <li className={selected === null ? 'active' : ''} onClick={() => onSelect(null)}>
          <span>All documents</span>
        </li>
        {docs.map((d) => (
          <li key={d.id} className={selected === d.id ? 'active' : ''} onClick={() => onSelect(d.id)}>
            <span title={d.title}>{d.title}</span>
            <small>{d.pages}p · {d.entities} entities</small>
            <button className="x" title="Delete" onClick={(e) => remove(e, d.id)}>×</button>
          </li>
        ))}
      </ul>
    </aside>
  )
}
