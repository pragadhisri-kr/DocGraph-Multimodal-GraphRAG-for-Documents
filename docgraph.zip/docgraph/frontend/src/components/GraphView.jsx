import { useEffect, useRef, useState } from 'react'
import { Network } from 'vis-network/standalone'
import { api } from '../api'

const PALETTE = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#06b6d4', '#a855f7', '#84cc16', '#ec4899', '#14b8a6']
const colorFor = (type) => {
  let h = 0
  for (const c of type || '') h = (h * 31 + c.charCodeAt(0)) >>> 0
  return PALETTE[h % PALETTE.length]
}

export default function GraphView({ docId }) {
  const box = useRef(null)
  const [state, setState] = useState({ loading: true, nodes: 0, edges: 0, error: null })
  const [picked, setPicked] = useState(null)

  useEffect(() => {
    let network
    let cancelled = false
    setState({ loading: true, nodes: 0, edges: 0, error: null })
    setPicked(null)

    api.graph(docId)
      .then((g) => {
        if (cancelled || !box.current) return
        const byId = Object.fromEntries(g.nodes.map((n) => [n.id, n]))
        const nodes = g.nodes.map((n) => ({
          id: n.id,
          label: n.name,
          value: 1 + n.degree,
          color: colorFor(n.type),
          font: { color: '#e5e7eb' },
        }))
        const edges = g.edges.map((e, i) => ({
          id: i, from: e.source, to: e.target, label: e.type,
          arrows: 'to', font: { size: 9, color: '#9ca3af', strokeWidth: 0 }, color: { color: '#4b5563' },
        }))
        network = new Network(box.current, { nodes, edges }, {
          nodes: { shape: 'dot', scaling: { min: 8, max: 30 } },
          physics: { stabilization: { iterations: 150 }, barnesHut: { gravitationalConstant: -4000 } },
          interaction: { hover: true },
        })
        network.on('click', (p) => setPicked(p.nodes.length ? byId[p.nodes[0]] : null))
        setState({ loading: false, nodes: nodes.length, edges: edges.length, error: null })
      })
      .catch((e) => !cancelled && setState({ loading: false, nodes: 0, edges: 0, error: e.message }))

    return () => { cancelled = true; network?.destroy() }
  }, [docId])

  return (
    <div className="graph">
      <div ref={box} className="canvas" />
      <div className="graph-info">
        {state.loading && <span>Loading graph…</span>}
        {state.error && <span className="error">{state.error}</span>}
        {!state.loading && !state.error && (
          <span>{state.nodes} entities · {state.edges} relationships{state.nodes === 0 && ' — upload a PDF to build a graph'}</span>
        )}
        {picked && (
          <div className="picked">
            <b>{picked.name}</b> <em>{picked.type}</em>
            <p>{picked.description || 'No description.'}</p>
          </div>
        )}
      </div>
    </div>
  )
}
