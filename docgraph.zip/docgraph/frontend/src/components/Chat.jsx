import { useEffect, useRef, useState } from 'react'
import { api } from '../api'

export default function Chat({ docId }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const end = useRef(null)

  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, loading])

  async function send(e) {
    e.preventDefault()
    const question = input.trim()
    if (!question || loading) return
    setInput('')
    setMessages((m) => [...m, { role: 'user', text: question }])
    setLoading(true)
    try {
      const r = await api.chat(question, docId)
      setMessages((m) => [...m, { role: 'bot', ...r, text: r.answer }])
    } catch (err) {
      setMessages((m) => [...m, { role: 'bot', text: err.message, failed: true }])
    }
    setLoading(false)
  }

  return (
    <div className="chat">
      <div className="messages">
        {messages.length === 0 && (
          <div className="empty">Upload a PDF, then ask a question about it.</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role} ${m.failed ? 'failed' : ''}`}>
            <p>{m.text}</p>
            {m.sources?.length > 0 && (
              <details>
                <summary>{m.sources.length} sources · {m.facts?.length || 0} graph facts</summary>
                {m.sources.map((s) => (
                  <blockquote key={s.id}>
                    <b>[{s.ref}] {s.doc}{s.page ? `, p.${s.page}` : ''}</b>
                    <div>{s.snippet}…</div>
                  </blockquote>
                ))}
                {m.facts?.length > 0 && <ul>{m.facts.map((f, j) => <li key={j}>{f}</li>)}</ul>}
              </details>
            )}
          </div>
        ))}
        {loading && <div className="msg bot muted">Thinking…</div>}
        <div ref={end} />
      </div>
      <form onSubmit={send}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about your documents…" />
        <button className="primary" disabled={loading || !input.trim()}>Send</button>
      </form>
    </div>
  )
}
